// Your OpenWeatherMap API key
const weatherApiKey = '89c3d0e11114e256f87783ce9f14720d';
const moonApiKey = '32d87ca770msh55fec434802799ep10ffb9jsn689773d4e5a5';

// Function to fetch weather data
async function fetchWeather(city) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${weatherApiKey}&units=metric`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
}

// Function to fetch moon phase data
async function fetchMoonPhase() {
    const url = `https://moon-phase.p.rapidapi.com/advanced?lat=51.4826&lon=0.0077`;
    const options = {
        method: 'GET',
        headers: {
            'x-rapidapi-key': moonApiKey,
            'x-rapidapi-host': 'moon-phase.p.rapidapi.com',
            'Content-Type': 'application/json',
        }
    };

    try {
        const response = await fetch(url, options);
        const data = await response.json();
        return data.moon.phase;
    } catch (error) {
        console.error('Error fetching moon phase data:', error);
        return null;
    }
}

async function fetchWeeklyMoonPhase() {
    const currentDate = new Date();
    let totalMoonPhase = 0;

    for (let i = 0; i < 7; i++) {
        const date = new Date(currentDate);
        date.setDate(date.getDate() + i);
        const formattedDate = date.toISOString().split('T')[0]; // Format date to YYYY-MM-DD

        const moonPhase = await fetchMoonPhaseByDate(formattedDate);
        totalMoonPhase += moonPhase;
    }

    const averageMoonPhase = totalMoonPhase / 7;
    return averageMoonPhase;
}

async function fetchMoonPhaseByDate(date) {
    const url = `https://moon-phase.p.rapidapi.com/advanced?date=${date}&lat=51.4826&lon=0.0077`;
    const options = {
        method: 'GET',
        headers: {
            'x-rapidapi-key': moonApiKey,
            'x-rapidapi-host': 'moon-phase.p.rapidapi.com',
            'Content-Type': 'application/json',
        }
    };

    try {
        const response = await fetch(url, options);
        const data = await response.json();
        return data.moon.phase;
    } catch (error) {
        console.error('Error fetching moon phase data:', error);
        return null;
    }
}

// Function to calculate natural light percentage
function calculateNaturalLight(moonPhase, weatherCondition) {
    const M = moonPhase; // Moon phase percentage (0 to 100)
    let w = 0; // Default weather condition

    // Determine weather condition factor
    if (weatherCondition === 'clear sky') {
        w = 1;
    } else if (weatherCondition === 'scattered clouds') {
        w = 0.75;
    } else if (weatherCondition === 'few clouds') {
        w = 0.5;
    } else if (weatherCondition === 'broken clouds') {
        w = 0.25;
    } else if (weatherCondition === 'overcast clouds') {
        w = 0;
    }

    // Calculate natural light percentage
    return (1 - M) * w * 100;
}

// Function to display forecast
async function showForecast(city, type) {
    const weatherData = await fetchWeather(city);

    if (type === 'today') {
        const moonPhase = await fetchMoonPhase();
        const weatherCondition = weatherData.weather[0].description;
        const naturalLight = calculateNaturalLight(moonPhase, weatherCondition);

        const forecast = document.getElementById('forecast');
        const { main: { temp, humidity }, weather } = weatherData;
        const description = weather[0].description;

        forecast.innerHTML = `
          <div class="moon">
            <div class="natural-light">${naturalLight.toFixed(1)}%</div>
          </div>
          <div class="extra-info">Natural light: ${description}<br>Humidity: ${humidity}%<br>Temperature: ${temp}°C</div>
        `;
        updateMoon(naturalLight);
    } else if (type === 'week') {
        const averageMoonPhase = await fetchWeeklyMoonPhase();
        const forecast = document.getElementById('forecast');
        forecast.innerHTML = `
          <div class="moon">
            <div class="natural-light">${averageMoonPhase.toFixed(1)}%</div>
          </div>
          <div class="extra-info"><br>Humidity: ${weatherData.main.humidity}%<br>Temperature: ${weatherData.main.temp}°C</div>
        `;
        updateMoon(averageMoonPhase);
    }
}

// Function to toggle forecast type
function toggleForecast(type) {
    const todayBtn = document.getElementById('today-btn');
    const weekBtn = document.getElementById('week-btn');
    const citySelect = document.getElementById('city-select');
    const city = citySelect.value;

    if (type === 'today') {
        todayBtn.classList.add('active');
        weekBtn.classList.remove('active');
        showForecast(city, 'today');
    } else {
        todayBtn.classList.remove('active');
        weekBtn.classList.add('active');
        showForecast(city, 'week');
    }
}

// Function to update moon display
function updateMoon(percentage) {
    const moon = document.querySelector('.moon');
    if (moon) {
        moon.style.setProperty('--moon-opacity', 1 - (percentage / 100));
    }
}

// Function to show contact form
function showContact() {
    const contactForm = document.getElementById('contact-form');
    contactForm.style.display = 'block';

    const faqs = document.getElementById('faqs');
    faqs.style.display = 'none';
}

// Function to show FAQs
function showFAQs() {
    const faqs = document.getElementById('faqs');
    faqs.style.display = 'block';

    const contactForm = document.getElementById('contact-form');
    contactForm.style.display = 'none';
}

// Initial setup
document.addEventListener('DOMContentLoaded', () => {
    const forecast = document.getElementById('forecast');
    forecast.innerHTML = `
        <div class="moon"></div>
        <div class="extra-info">Natural light: 80%<br>Humidity: 60%<br>Temperature: 20°C</div>`;
    updateMoon(80);

    const todayBtn = document.getElementById('today-btn');
    const weekBtn = document.getElementById('week-btn');
    const citySelect = document.getElementById('city-select');

    todayBtn.addEventListener('click', () => {
        const user = new User();
        user.setLocation(citySelect.value);
        user.SearchDay();
    });

    weekBtn.addEventListener('click', () => {
        const user = new User();
        user.setLocation(citySelect.value);
        user.SearchWeek();
    });

    citySelect.addEventListener('change', () => {
        const user = new User();
        user.setLocation(citySelect.value);
        user.SearchDay();
    });

    const user = new User();
    user.setLocation(citySelect.value);
    user.SearchDay();
});

class User {
    constructor() {
        this.searchType = null;
        this.location = null;
    }

    SearchWeek() {
        this.searchType = 'week';
        this.showForecast();
    }

    SearchDay() {
        this.searchType = 'today';
        this.showForecast();
    }

    setLocation(location) {
        this.location = location;
    }

    showForecast() {
        const predictionSystem = new PredictionSystem();
        if (this.searchType === 'today') {
            predictionSystem.getForecast(this.location, 'today')
                .then(forecastData => {
                    LightPrediction.GetPredictionPercentage(this.location, 'today')
                        .then(prediction => {
                            const forecast = document.getElementById('forecast');
                            forecast.innerHTML = `
                                <div class="moon">
                                    <div class="natural-light">${prediction.toFixed(1)}%</div>
                                </div>
                                <div class="extra-info">Natural light: ${forecastData.weatherCondition}<br>Humidity: ${forecastData.humidity}%<br>Temperature: ${forecastData.temp}°C</div>
                            `;
                            updateMoon(prediction);
                        });
                });
        } else if (this.searchType === 'week') {
            predictionSystem.getForecast(this.location, 'week')
                .then(forecastData => {
                    LightPrediction.GetPredictionPercentage(this.location, 'week')
                        .then(prediction => {
                            const forecast = document.getElementById('forecast');
                            forecast.innerHTML = `
                                <div class="moon">
                                    <div class="natural-light">${prediction.toFixed(1)}%</div>
                                </div>
                                <div class="extra-info">Natural light: ${forecastData.weatherCondition}<br>Humidity: ${forecastData.humidity}%<br>Temperature: ${forecastData.temp}°C</div>
                            `;
                            updateMoon(prediction);
                        });
                });
        }
    }
}

class PredictionSystem {
    async getForecast(city, type) {
        const weatherData = await fetchWeather(city);
        if (type === 'today') {
            const weatherCondition = weatherData.weather[0].description;
            const { main: { temp, humidity } } = weatherData;
            return { weatherCondition, temp, humidity };
        } else if (type === 'week') {
            const weatherCondition = weatherData.weather[0].description;
            const { main: { temp, humidity } } = weatherData;
            return { weatherCondition, temp, humidity };
        }
    }
}

class LightPrediction {
    static async GetPredictionPercentage(city, type) {
        if (type === 'today') {
            const moonPhase = await fetchMoonPhase();
            const weatherData = await fetchWeather(city);
            const weatherCondition = weatherData.weather[0].description;
            return calculateNaturalLight(moonPhase, weatherCondition);
        } else if (type === 'week') {
            const averageMoonPhase = await fetchWeeklyMoonPhase();
            const weatherData = await fetchWeather(city);
            const weatherCondition = weatherData.weather[0].description;
            return calculateNaturalLight(averageMoonPhase, weatherCondition);
        }
    }
}
